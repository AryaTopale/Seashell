#ifndef __PEEK_H
#define __PEEK_H

char* peek(char* remaining_token , char* root_directory , char*previous_directory);

#endif