#ifndef __ACTIVITIES__
#define __ACTIVITIES__

#include "headers.h"
#include "linked_list.h"

char* activities(char* remaining_token  );

#endif 