#ifndef WARP
#define WARP

char* warp(char*remaining_token , char*root_directory , int*changes , char*previous_directory_maintained );

#endif