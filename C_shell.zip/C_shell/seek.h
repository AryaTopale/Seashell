#ifndef SEEK
#define SEEK

char* seek(char*root_directory , char*remaining_token , int*changes , char*previous_directory);

#endif