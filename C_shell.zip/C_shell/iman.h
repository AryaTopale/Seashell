#ifndef __IMAN__

#define __IMAN__

#include "headers.h"
#define MAX_BUFFER_SIZE 4096
char* iman(char* remianing_token);

#endif