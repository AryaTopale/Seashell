#ifndef __PROCLURE__
#define __PROCLURE__

#include "headers.h"

char* proclure(char* remaining_token , char*root_directory);

#endif