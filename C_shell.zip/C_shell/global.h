#ifndef __GLOBAL__
#define __GLOBAL__

#include "headers.h"
#include "linked_list.h"

extern Node* for_activities;
extern int child_pid_global;
extern jmp_buf env ;
extern char*input_string;


#endif