#ifndef __PROMPT_H
#define __PROMPT_H

void prompt(char* root_directory ,int size , int time , char*command);

#endif