#ifndef __FG__
#define __FG__

#include "headers.h"

void fg(char* pid );
void bg(char* pid);


#endif